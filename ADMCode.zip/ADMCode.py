import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
'exec(%matplotlib inline)'
import seaborn as sns
import warnings  
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Lasso
from sklearn.ensemble import GradientBoostingRegressor
import xgboost as xgb

#importing for applying models
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.decomposition import PCA
warnings.filterwarnings('ignore')

#######################DATA PRE-PROCESSING################################

#read the data below
data = pd.read_csv('C:/Users/Smit/Desktop/data.csv')
data.dtypes
#remove the data not required
data = data.drop(['ID','Unnamed: 0','Photo','Potential','Preferred Foot','Real Face','Loaned From','Joined','Jersey Number','Contract Valid Until','Release Clause','Flag','Nationality','Club','Club Logo','Wage','Value','Special'],axis=1)
data = data.drop(data.iloc[:,11:37].columns,axis=1)
data.dtypes
data.iloc[:,0:20].head(10)
data.iloc[:,20:40].head(10)
data.iloc[:,40:45].head(10)
data.info()
data.isnull().sum()

#impute the missing data
from sklearn.impute import SimpleImputer
imputer = SimpleImputer(strategy='mean',missing_values = np.nan)

data.iloc[:,3:4] = imputer.fit_transform(data.iloc[:,3:4])
data.iloc[:,4:5] = imputer.fit_transform(data.iloc[:,4:5])
data.iloc[:,5:6] = imputer.fit_transform(data.iloc[:,5:6])
data.iloc[:,11:12] = imputer.fit_transform(data.iloc[:,11:12])
data.iloc[:,12:13] = imputer.fit_transform(data.iloc[:,12:13])
data.iloc[:,13:14] = imputer.fit_transform(data.iloc[:,13:14])
data.iloc[:,14:15] = imputer.fit_transform(data.iloc[:,14:15])
data.iloc[:,15:16] = imputer.fit_transform(data.iloc[:,15:16])
data.iloc[:,16:17] = imputer.fit_transform(data.iloc[:,16:17])
data.iloc[:,17:18] = imputer.fit_transform(data.iloc[:,17:18])
data.iloc[:,18:19] = imputer.fit_transform(data.iloc[:,18:19])
data.iloc[:,19:20] = imputer.fit_transform(data.iloc[:,19:20])
data.iloc[:,20:21] = imputer.fit_transform(data.iloc[:,20:21])
data.iloc[:,21:22] = imputer.fit_transform(data.iloc[:,21:22])
data.iloc[:,22:23] = imputer.fit_transform(data.iloc[:,22:23])
data.iloc[:,23:24] = imputer.fit_transform(data.iloc[:,23:24])
data.iloc[:,24:25] = imputer.fit_transform(data.iloc[:,24:25])
data.iloc[:,25:26] = imputer.fit_transform(data.iloc[:,25:26])
data.iloc[:,26:27] = imputer.fit_transform(data.iloc[:,26:27])
data.iloc[:,27:28] = imputer.fit_transform(data.iloc[:,27:28])
data.iloc[:,28:29] = imputer.fit_transform(data.iloc[:,28:29])
data.iloc[:,29:30] = imputer.fit_transform(data.iloc[:,29:30])
data.iloc[:,30:31] = imputer.fit_transform(data.iloc[:,30:31])
data.iloc[:,31:32] = imputer.fit_transform(data.iloc[:,31:32])
data.iloc[:,32:33] = imputer.fit_transform(data.iloc[:,32:33])
data.iloc[:,33:34] = imputer.fit_transform(data.iloc[:,33:34])
data.iloc[:,34:35] = imputer.fit_transform(data.iloc[:,34:35])
data.iloc[:,35:36] = imputer.fit_transform(data.iloc[:,35:36])
data.iloc[:,36:37] = imputer.fit_transform(data.iloc[:,36:37])
data.iloc[:,37:38] = imputer.fit_transform(data.iloc[:,37:38])
data.iloc[:,38:39] = imputer.fit_transform(data.iloc[:,38:39])
data.iloc[:,39:40] = imputer.fit_transform(data.iloc[:,39:40])
data.iloc[:,40:41] = imputer.fit_transform(data.iloc[:,40:41])
data.iloc[:,41:42] = imputer.fit_transform(data.iloc[:,41:42])
data.iloc[:,42:43] = imputer.fit_transform(data.iloc[:,42:43])
data.iloc[:,43:44] = imputer.fit_transform(data.iloc[:,43:44])
data.iloc[:,44:45] = imputer.fit_transform(data.iloc[:,44:45])

data.isnull().sum()

#remove NAs from remaining columns
data = data.dropna(subset=['Height'])
categorical_imputer = SimpleImputer(strategy='constant',missing_values=np.nan)
data.iloc[:,8:9] = categorical_imputer.fit_transform(data.iloc[:,8:9])

data.isnull().sum()

#############Correlation Matrix#################
#plot a heat map
plt.figure(figsize=(20,12))
sns.heatmap(data.corr(), cmap="YlGnBu")

# delete the data not required
data = data.drop(['Position','SlidingTackle','StandingTackle','BallControl','Balance','GKDiving','GKHandling','GKKicking','GKPositioning','GKReflexes'],axis=1)


########convert height in to cms#################
height_cm = []
for value in data['Height'].values :
    feet = float(value.split('\'')[0])
    inch = float(value.split('\'')[1])
    cm = feet * 30.48 + inch * 2.54
    height_cm.append(round(cm, 2))
    
data['Height_class'] = data['Height']
data.drop(['Height'],axis=1)
data['Height'] = height_cm

#categorizing height of the players
data['Height_class'][data['Height'] <= 173] ='Short'
data['Height_class'][(data['Height'] > 173) & (data['Height'] <= 186)] ='Middle'
data['Height_class'][data['Height'] > 186] ='Tall'
data = data.drop(['Height'],axis=1)

#converting the weight of the players into kg
import re
weight_kg = []
for value in data['Weight'].values:
    lbs = float(re.findall(r'\d+',value)[0])
    kg = lbs * 0.45
    weight_kg.append(round(kg, 2))
 
data['Weight_class'] = data['Weight']
data.drop(['Weight'],axis=1)
data['Weight'] = weight_kg

#########preliminary data analysis###############
#categorizing the players on the basis of weights
data['Weight_class'][data['Weight'] <= 67] ='Thin'
data['Weight_class'][(data['Weight'] > 67) & (data['Weight'] <= 81)] ='Normal'
data['Weight_class'][data['Weight'] > 81] ='Fat'
data = data.drop(['Weight'],axis=1)
##################################################

#plot all the players on a graph based on height
f,ax = plt.subplots(1,2,figsize=(18,8))
sns.boxenplot(x='Weight_class',y='Overall',data=data,ax=ax[0])
sns.countplot('Weight_class',data=data,palette="ch:.25",ax=ax[1])

work_rates = pd.get_dummies(data['Work Rate'])
body_types = pd.get_dummies(data['Body Type'])
height_class = pd.get_dummies(data['Height_class'])
weight_class = pd.get_dummies(data['Weight_class'])

data = data.drop(['Work Rate','Body Type','Height_class','Weight_class'],axis=1)
data = pd.concat([data,work_rates],axis=1)
data = pd.concat([data,body_types],axis=1)
data = pd.concat([data,height_class],axis=1)
data = pd.concat([data,weight_class],axis=1)

#removing columns which are not required.
data.columns
data = data.drop(['Name','Weak Foot','Acceleration','SprintSpeed','Agility','Jumping','Marking','High/ High','High/ Low','High/ Medium','Low/ High','Low/ Low','Low/ Medium','Medium/ High','Medium/ Low','Medium/ Medium','Lean','Normal','Stocky','Middle','Short','Tall','Fat','Normal','Thin'],axis=1)
plt.figure(figsize=(20,8))
#sns.heatmap(data.corr(),annot=True)

##############SPLIT THE DATA INTO TEST AND TRAIN SAMPLES#####################
df =pd.read_csv('C:/Users/Smit/Desktop/data.csv')

#from sklearn.model_selection import train_test_split
Y = data.iloc[:,1:2]
X = pd.concat([data.iloc[:,0:1],data.iloc[:,2:]],axis=1)
#X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.33, random_state=0)

# Encode text values to indexes(i.e. [1],[2],[3] for red,green,blue).
def encode_text_index(df, name):
    le = preprocessing.LabelEncoder()
    df[name] = le.fit_transform(df[name])
    return le.classes_


# Remove all rows where the specified column is +/- sd standard deviations
def remove_outliers(df, name, sd):
    drop_rows = df.index[(np.abs(df[name] - df[name].mean()) >= (sd * df[name].std()))]
    df.drop(drop_rows, axis=0, inplace=True)


# Encode a column to a range between normalized_low and normalized_high.
def encode_numeric_range(df, name, normalized_low=0, normalized_high=1,
                         data_low=None, data_high=None):
    if data_low is None:
        data_low = min(df[name])
        data_high = max(df[name])

    df[name] = ((df[name] - data_low) / (data_high - data_low)) \
               * (normalized_high - normalized_low) + normalized_low
               

# filling the missing value for the continous variables.
df['ShortPassing'].fillna(df['ShortPassing'].mean(), inplace = True)
df['Volleys'].fillna(df['Volleys'].mean(), inplace = True)
df['Dribbling'].fillna(df['Dribbling'].mean(), inplace = True)
df['Curve'].fillna(df['Curve'].mean(), inplace = True)
df['FKAccuracy'].fillna(df['FKAccuracy'], inplace = True)
df['LongPassing'].fillna(df['LongPassing'].mean(), inplace = True)
df['BallControl'].fillna(df['BallControl'].mean(), inplace = True)
df['HeadingAccuracy'].fillna(df['HeadingAccuracy'].mean(), inplace = True)
df['Finishing'].fillna(df['Finishing'].mean(), inplace = True)
df['Crossing'].fillna(df['Crossing'].mean(), inplace = True)
df['Weight'].fillna('200lbs', inplace = True)
df['Contract Valid Until'].fillna(2019, inplace = True)
df['Height'].fillna("5'11", inplace = True)
df['Loaned From'].fillna('None', inplace = True)
df['Joined'].fillna('Jul 1, 2018', inplace = True)
df['Jersey Number'].fillna(8, inplace = True)
df['Body Type'].fillna('Normal', inplace = True)
df['Position'].fillna('ST', inplace = True)
df['Club'].fillna('No Club', inplace = True)
df['Work Rate'].fillna('Medium/ Medium', inplace = True)
df['Skill Moves'].fillna(df['Skill Moves'].median(), inplace = True)
df['Weak Foot'].fillna(3, inplace = True)
df['Preferred Foot'].fillna('Right', inplace = True)
df['International Reputation'].fillna(1, inplace = True)
df['Wage'].fillna('€200K', inplace = True)    
    
df.dropna()

col = ['Age', 'Potential', 'Crossing', 'Finishing', 'HeadingAccuracy', 'ShortPassing', 'Volleys', 'Dribbling', 'Curve', 'FKAccuracy', 'LongPassing', 'BallControl', 'Acceleration', 'SprintSpeed', 'Agility', 'Reactions', 'Balance', 'ShotPower', 'Jumping' ,'Stamina', 'Strength', 'LongShots', 'Aggression', 'Interceptions', 'Positioning' ,'Vision', 'Penalties', 'Composure', 'Marking', 'StandingTackle', 'SlidingTackle', 'GKDiving', 'GKHandling', 'GKKicking', 'GKPositioning', 'GKReflexes']

for x in col:
    encode_numeric_range(df,x)    
    
#Label encoding

encode_text_index(df,'Preferred Foot')
encode_text_index(df,'Body Type')    
    
df.columns    
    
df.dropna(inplace = True) 
############################################################
col = ['Age', 'Potential', 'Crossing', 'Finishing', 'HeadingAccuracy', 'ShortPassing', 'Volleys', 'Dribbling', 'Curve', 'FKAccuracy', 'LongPassing', 'BallControl', 'Acceleration', 'SprintSpeed', 'Agility', 'Reactions', 'Balance', 'ShotPower', 'Jumping' ,'Stamina', 'Strength', 'LongShots', 'Aggression', 'Interceptions', 'Positioning' ,'Vision', 'Penalties', 'Composure', 'Marking', 'StandingTackle', 'SlidingTackle', 'GKDiving', 'GKHandling', 'GKKicking', 'GKPositioning', 'GKReflexes']

for x in col:
    remove_outliers(df,x,3)   
    
df_x = df[['Age','Potential', 'Crossing', 'Finishing', 'HeadingAccuracy', 'ShortPassing', 'Volleys', 'Dribbling', 'Curve', 'FKAccuracy', 'LongPassing', 'BallControl', 'Acceleration', 'SprintSpeed', 'Agility', 'Reactions', 'Balance', 'ShotPower', 'Jumping' ,'Stamina', 'Strength', 'LongShots', 'Aggression', 'Interceptions', 'Positioning' ,'Vision', 'Penalties', 'Composure', 'Marking', 'StandingTackle', 'SlidingTackle', 'GKDiving', 'GKHandling', 'GKKicking', 'GKPositioning', 'GKReflexes', 'Preferred Foot', 'Body Type']].copy() 
df_x

df_y = df['Overall'].copy()
df_y.head()
############################################################

###########PRELIMINARY DATA ANALYSIS########################

from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2

chi2_best = SelectKBest(chi2, k=20)

X_ch2 = chi2_best.fit_transform(df_x,df_y)

# this is a relatively strait-forward way to get to two highest indicies
max_indx = pd.Series(np.argsort(chi2_best.scores_), name='score')\
                    .nlargest(n=20).\
                    index.values
        
print('The best features of the chi2 test are:\n')

for i in range(20):
    # the +1 factor is because 
    print('{}. {}'.format(i+1, df_x.columns[max_indx[i] + 1]))
    
df_sel_x = df_x[["StandingTackle", "FKAccuracy", "HeadingAccuracy", "Potential", "Finishing", "ShortPassing", "Crossing", "Agility", "Jumping", "Stamina", "GKKicking",     
                "Acceleration", "Composure", "LongShots", "Vision", "Marking", "GKPositioning", "SprintSpeed", "Reactions", "BallControl"]].copy() 

X = np.array(df_x)
Y = np.array(df_y)

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=1 )

#######################################################################

###########PRELIMINARY DATA ANALYSIS########################

#PCA
X = data.drop('Overall',1)
y = data['Overall']

from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)


from sklearn.preprocessing import StandardScaler

sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

from sklearn.decomposition import PCA

pca = PCA(n_components=5)
X_train = pca.fit_transform(X_train)
X_test = pca.transform(X_test)

######################################################################
###########################APPLYING MODELS############################

#random forest
rf = RandomForestRegressor(n_estimators=10,random_state=0)
rf.fit(X_train,y_train)
rf_predict = rf.predict(X_test)
rf_mae = mean_absolute_error(y_test,rf_predict)
rf_mse = mean_squared_error(y_test,rf_predict)
rf_rmse = np.sqrt(rf_mse)
rf_r2 =  r2_score(y_test,rf_predict)

print('MODEL: Random Forest Regression')
print('Actual values:', y_test)
print('Predicted values:', rf_predict)
print("Mean Squared Error : ", rf_mse)
print("Root Mean Squared Error : ", rf_rmse)
print("Mean Absolute Error : ", rf_mae)
print("R2 score : ", rf_r2)

#############################################

#applying linear regression
lr = LinearRegression()
lr.fit(X_train,y_train)
linear_predict = lr.predict(X_test)
linear_mae = mean_absolute_error(y_test,linear_predict)
linear_mse = mean_squared_error(y_test,linear_predict)
linear_rmse = np.sqrt(linear_mse)
linear_r2 = r2_score(y_test,linear_predict)

print('MODEL: Linear Regression')
print('Actual values:', y_test)
print('Predicted values:', linear_predict)
print("Mean Squared Error : ", linear_mse)
print("Root Mean Squared Error : ", linear_rmse)
print("Mean Absolute Error : ", linear_mae)
print("R2 score : ", linear_r2)

##########################################

#linear SVR model
svr_linear = LinearSVR()
svr_linear.fit(X_train,y_train)
svr_linear_predict = svr_linear.predict(X_test)
svr_linear_mae = mean_absolute_error(y_test,svr_linear_predict)
svr_linear_mse = mean_squared_error(y_test,svr_linear_predict)
svr_linear_rmse = np.sqrt(svr_linear_mse)
svr_linear_r2 = r2_score(y_test,svr_linear_predict)

print('MODEL: LinearSVR Regression')
print('Actual values:', y_test)
print('Predicted values:', svr_linear_predict)
print("Mean Squared Error : ", svr_linear_mse)
print("Root Mean Squared Error : ", svr_linear_rmse)
print("Mean absolute error : ",svr_linear_mae)
print("R2 score : ", svr_linear_r2)
##########################################

#Gradient Boosting model
gdb = GradientBoostingRegressor(n_estimators=200).fit(X_train,y_train)
gdb_pred = gdb.predict(X_test)
gdb_mse  = mean_squared_error(gdb_pred, y_test)
gdb_rmse = np.sqrt(gdb_mse)
gdb_mae = mean_absolute_error(y_test,gdb_pred)

print ('MODEL: Gradient Boosting')
print('Actual values:', y_test)
print('Predicted values:', gdb_pred)
print('MSE Score for Ridge:',gdb_mse)
print('RMSE Score for Gradient Boosting:',gdb_rmse)
print('MAE Score for Gradient Boosting:', gdb_mae)
print('R2 score: %.2f' % r2_score(y_test, gdb_pred))

###########################

#decision trees
dtree = DecisionTreeRegressor(random_state=0)
dtree.fit(X_train,y_train)
dtree_predict = dtree.predict(X_test)
dtree_mae = mean_absolute_error(y_test,dtree_predict)
dtree_mse = mean_squared_error(y_test,dtree_predict)
dtree_rmse = np.sqrt(dtree_mse)
dtree_r2 = r2_score(y_test,dtree_predict)

print('MODEL: Decision Tree Regression')
print('Actual values:', y_test)
print('Predicted values:', dtree_predict)
print("Mean Squared Error : ", dtree_mse)
print("Root Mean Squared Error : ", dtree_rmse)
print("Mean Absolute Error : ", dtree_mae)
print("R2 score : ", dtree_r2)

######################################################################

#XGBoost
xgb = xgb.XGBRegressor(objective ='reg:linear', colsample_bytree = 0.5, learning_rate = 0.1,
                max_depth = 3, alpha = 10, n_estimators = 10000).fit(X_train,y_train)
xgb_pred = xgb.predict(X_test)
xgb_mse  = mean_squared_error(xgb_pred, y_test)
xgb_rmse = np.sqrt(xgb_mse)
xgb_mae = mean_absolute_error(y_test,xgb_pred)

print ('MODEL: XGBoost')
print('Actual values:', y_test)
print('Predicted values:', xgb_pred)
print('Mean Squared Error:',xgb_mse)
print('Root Mean Squared Error:',xgb_rmse)
print('Mean Absolute Error :', xgb_mae)
print('R2 for XGBoost: %.2f' % r2_score(y_test, xgb_pred))

######################################################################

lasso = Lasso(alpha =0.0005, random_state=10).fit(X_train,y_train)
lasso_pred = lasso.predict(X_test)
lasso_mse  = mean_squared_error(lasso_pred, y_test)
lasso_rmse = np.sqrt(lasso_mse)
lasso_mae = mean_absolute_error(y_test,lasso_pred)

print ('MODEL: Lasso')
print('Actual values:', y_test)
print('Predicted values:', lasso_pred)
print('Mean Squared Error:',lasso_mse)
print('Root Mean Squared Error:',lasso_rmse)
print('Mean Absolute Error :', lasso_mae)
print('R2 for Lasso: %.2f' % r2_score(y_test, lasso_pred))

##########################################
#comparision of the models
r2_scores = [linear_r2,dtree_r2,rf_r2,svr_linear_r2, r2_score(y_test, gdb_pred), r2_score(y_test, xgb_pred), r2_score(y_test, lasso_pred)]
mean_absolute_errors = [linear_mae,dtree_mae,rf_mae,svr_linear_mae, gdb_mae, xgb_mae, lasso_mae]
mean_squared_errors = [linear_mse,dtree_mse,rf_mse,svr_linear_mse, gdb_rmse, xgb_rmse, lasso_rmse]
models = ['Linear','Decision Tree','Random Forest','Linear SVR', 'Gradient Boosting', 'XGBoosting', 'Lasso']
model_accuracy = pd.DataFrame({'model' : models,
                               'R2 score' : r2_scores,
                              'Mean absolute error' : mean_absolute_errors,
                               'Mean squared error' : mean_squared_errors})
print(model_accuracy)
#End of code